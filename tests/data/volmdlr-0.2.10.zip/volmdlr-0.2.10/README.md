# Volmdlr

A python VOLume MoDeLeR computations-oriented with STEP support for import/export

![badge](https://drone-opensource.dessia.tech/api/badges/Dessia-tech/volmdlr/status.svg?branch=master)

![casing](https://raw.githubusercontent.com/Dessia-tech/volmdlr/master/doc/source/images/casing.jpg)

## Installing

.. code::

  pip(3) install volmdlr

## Documentation
https://volmdlr.readthedocs.io/en/latest/

## Contributors

- [DessiA team](https://github.com/orgs/Dessia-tech/people)
- [Mack Joly](https://www.linkedin.com/in/mack-joly-979824182/)

